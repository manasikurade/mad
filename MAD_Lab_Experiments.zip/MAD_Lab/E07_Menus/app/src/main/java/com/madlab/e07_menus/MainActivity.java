package com.madlab.e07_menus;

import android.os.Bundle;
import android.view.*;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult = findViewById(R.id.tvResult);
        TextView tvContextItem = findViewById(R.id.tvContextItem);
        Button btnPopup = findViewById(R.id.btnPopup);
        Button btnTouchMode = findViewById(R.id.btnTouchMode);

        // Register context menu
        registerForContextMenu(tvContextItem);

        // Popup menu
        btnPopup.setOnClickListener(v -> {
            PopupMenu popup = new PopupMenu(this, btnPopup);
            popup.getMenuInflater().inflate(R.menu.popup_menu, popup.getMenu());
            popup.setOnMenuItemClickListener(item -> {
                tvResult.setText("Popup selected: " + item.getTitle());
                Toast.makeText(this, "Popup: " + item.getTitle(), Toast.LENGTH_SHORT).show();
                return true;
            });
            popup.show();
        });

        // Touch mode check
        btnTouchMode.setOnClickListener(v -> {
            boolean inTouchMode = v.isInTouchMode();
            tvResult.setText("Device is " + (inTouchMode ? "IN Touch Mode ✓" : "NOT in Touch Mode"));
            Toast.makeText(this, "Touch Mode: " + inTouchMode, Toast.LENGTH_SHORT).show();
        });
    }

    // Options Menu
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.options_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        String title = item.getTitle().toString();
        tvResult.setText("Options Menu: " + title);
        Toast.makeText(this, "Options: " + title, Toast.LENGTH_SHORT).show();
        if (item.getItemId() == R.id.menu_exit) finish();
        return true;
    }

    // Context Menu
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        menu.setHeaderTitle("Choose Action");
        getMenuInflater().inflate(R.menu.context_menu, menu);
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        String title = item.getTitle().toString();
        tvResult.setText("Context Menu: " + title);
        Toast.makeText(this, "Context: " + title, Toast.LENGTH_SHORT).show();
        return true;
    }
}
