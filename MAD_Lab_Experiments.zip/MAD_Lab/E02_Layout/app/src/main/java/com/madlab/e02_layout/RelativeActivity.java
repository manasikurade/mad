package com.madlab.e02_layout;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
public class RelativeActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_relative);
        if (getSupportActionBar() != null) getSupportActionBar().setTitle("Relative Layout");
    }
}
