package com.madlab.e02_layout;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class GridActivity extends AppCompatActivity {
    String[] items = {"Android","Java","XML","Layout","View","Widget",
                      "Intent","Activity","Fragment","Service","Broadcast","Content"};
    int[] colors = {0xFF1565C0,0xFF283593,0xFF1976D2,0xFF0288D1,0xFF00838F,0xFF006064,
                    0xFF2E7D32,0xFF558B2F,0xFFE65100,0xFFBF360C,0xFF4A148C,0xFF880E4F};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);
        if (getSupportActionBar() != null) getSupportActionBar().setTitle("Grid View");
        GridView gridView = findViewById(R.id.gridView);
        gridView.setAdapter(new GridAdapter(this));
        gridView.setOnItemClickListener((parent, view, position, id) ->
            Toast.makeText(this, "Selected: " + items[position], Toast.LENGTH_SHORT).show());
    }

    class GridAdapter extends BaseAdapter {
        Context context;
        GridAdapter(Context c) { context = c; }

        @Override public int getCount() { return items.length; }
        @Override public Object getItem(int pos) { return items[pos]; }
        @Override public long getItemId(int pos) { return pos; }

        @Override
        public View getView(int pos, View convertView, ViewGroup parent) {
            View v = getLayoutInflater().inflate(R.layout.grid_item, null);
            TextView tv = v.findViewById(R.id.tvItem);
            tv.setText(items[pos]);
            v.setBackgroundColor(colors[pos % colors.length]);
            return v;
        }
    }
}
