# Mobile Application Development Lab
## B.Tech. (C.S.E.) - II | Textile and Engineering Institute, Ichalkaranji

All experiments are written in **Java** and tested on Android API 21+ (Android 5.0 Lollipop and above).

---

## How to Open Each Experiment in Android Studio

1. Open Android Studio
2. Click **"Open an existing project"**
3. Navigate to the experiment folder (e.g., `E02_Layout`)
4. Click OK — Android Studio will sync Gradle automatically
5. Connect an emulator or physical device
6. Click ▶ **Run**

---

## Experiment List

| No. | Folder | Title |
|-----|--------|-------|
| E02 | `E02_Layout` | Different Layouts (Linear, Relative, Table, Frame, Grid) |
| E03 | `E03_Intent` | Intents for Switching Between Activities |
| E04 | `E04_Button` | Buttons, Text Fields, Checkboxes, Radio Buttons, Toggle |
| E05 | `E05_SMS` | Intents for SMS and Telephony |
| E06 | `E06_Spinners` | Spinners, Alerts, Popups, and Toasts |
| E07 | `E07_Menus` | Touch Mode and Menus (Options, Context, Popup) |
| E08 | `E08_Notifications` | Notifications with Actions |
| E09 | `E09_Calculator` | **Bonus** - Calculator App |

---

## Requirements

- Android Studio Hedgehog (2023.1.1) or newer
- JDK 8 or higher
- Android SDK API 34 (targetSdk)
- Minimum SDK: API 21 (Android 5.0)

---

## Notes

- Each experiment is an **independent Android project** — open them one at a time.
- All code is in **Java** (not Kotlin).
- E05 SMS requires a **real device** to test calling/SMS (emulator has limited support).
- E08 Notifications: on Android 13+, you must grant the notification permission when prompted.
