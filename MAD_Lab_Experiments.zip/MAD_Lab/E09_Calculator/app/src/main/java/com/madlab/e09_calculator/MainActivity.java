package com.madlab.e09_calculator;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private TextView tvResult, tvExpression;
    private String currentInput = "";
    private String operator = "";
    private double firstOperand = 0;
    private boolean operatorPressed = false;
    private boolean justCalculated = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvResult     = findViewById(R.id.tvResult);
        tvExpression = findViewById(R.id.tvExpression);

        // Number buttons
        int[] numIds = {R.id.btn0, R.id.btn1, R.id.btn2, R.id.btn3, R.id.btn4,
                        R.id.btn5, R.id.btn6, R.id.btn7, R.id.btn8, R.id.btn9};
        String[] nums = {"0","1","2","3","4","5","6","7","8","9"};
        for (int i = 0; i < numIds.length; i++) {
            final String num = nums[i];
            ((Button) findViewById(numIds[i])).setOnClickListener(v -> onNumberPressed(num));
        }

        ((Button) findViewById(R.id.btnDot)).setOnClickListener(v -> onDotPressed());
        ((Button) findViewById(R.id.btnClear)).setOnClickListener(v -> onClear());
        ((Button) findViewById(R.id.btnSign)).setOnClickListener(v -> onSign());
        ((Button) findViewById(R.id.btnPercent)).setOnClickListener(v -> onPercent());

        ((Button) findViewById(R.id.btnAdd)).setOnClickListener(v -> onOperator("+"));
        ((Button) findViewById(R.id.btnSubtract)).setOnClickListener(v -> onOperator("-"));
        ((Button) findViewById(R.id.btnMultiply)).setOnClickListener(v -> onOperator("×"));
        ((Button) findViewById(R.id.btnDivide)).setOnClickListener(v -> onOperator("÷"));
        ((Button) findViewById(R.id.btnEquals)).setOnClickListener(v -> onEquals());
    }

    private void onNumberPressed(String num) {
        if (justCalculated) { currentInput = ""; justCalculated = false; }
        if (currentInput.equals("0") && !num.equals(".")) currentInput = "";
        if (operatorPressed) { currentInput = ""; operatorPressed = false; }
        currentInput += num;
        tvResult.setText(formatDisplay(currentInput));
    }

    private void onDotPressed() {
        if (justCalculated) { currentInput = "0"; justCalculated = false; }
        if (operatorPressed) { currentInput = "0"; operatorPressed = false; }
        if (!currentInput.contains(".")) {
            if (currentInput.isEmpty()) currentInput = "0";
            currentInput += ".";
            tvResult.setText(currentInput);
        }
    }

    private void onOperator(String op) {
        if (!currentInput.isEmpty() && !operatorPressed) {
            if (!operator.isEmpty()) {
                performCalculation();
            } else {
                firstOperand = parseDouble(currentInput);
            }
        }
        operator = op;
        operatorPressed = true;
        justCalculated = false;
        tvExpression.setText(formatDisplay(String.valueOf(firstOperand)) + " " + op);
    }

    private void onEquals() {
        if (!operator.isEmpty() && !currentInput.isEmpty() && !operatorPressed) {
            double secondOperand = parseDouble(currentInput);
            tvExpression.setText(formatDisplay(String.valueOf(firstOperand)) + " " + operator
                    + " " + formatDisplay(currentInput) + " =");
            performCalculation();
            operator = "";
            justCalculated = true;
        }
    }

    private void performCalculation() {
        double secondOperand = parseDouble(currentInput);
        double result = 0;
        switch (operator) {
            case "+": result = firstOperand + secondOperand; break;
            case "-": result = firstOperand - secondOperand; break;
            case "×": result = firstOperand * secondOperand; break;
            case "÷":
                if (secondOperand == 0) { tvResult.setText("Error"); return; }
                result = firstOperand / secondOperand; break;
        }
        firstOperand = result;
        currentInput = formatResult(result);
        tvResult.setText(formatDisplay(currentInput));
    }

    private void onClear() {
        currentInput = "";
        operator = "";
        firstOperand = 0;
        operatorPressed = false;
        justCalculated = false;
        tvResult.setText("0");
        tvExpression.setText("");
    }

    private void onSign() {
        if (!currentInput.isEmpty() && !currentInput.equals("0")) {
            if (currentInput.startsWith("-")) currentInput = currentInput.substring(1);
            else currentInput = "-" + currentInput;
            tvResult.setText(formatDisplay(currentInput));
        }
    }

    private void onPercent() {
        if (!currentInput.isEmpty()) {
            double val = parseDouble(currentInput) / 100.0;
            currentInput = formatResult(val);
            tvResult.setText(formatDisplay(currentInput));
        }
    }

    private double parseDouble(String s) {
        try { return Double.parseDouble(s); } catch (NumberFormatException e) { return 0; }
    }

    private String formatResult(double d) {
        if (d == (long) d) return String.valueOf((long) d);
        return String.valueOf(d);
    }

    private String formatDisplay(String s) {
        if (s == null || s.isEmpty()) return "0";
        return s;
    }
}
