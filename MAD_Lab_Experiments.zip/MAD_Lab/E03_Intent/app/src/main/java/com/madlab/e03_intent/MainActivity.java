package com.madlab.e03_intent;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE = 100;
    EditText etName, etMessage;
    TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName    = findViewById(R.id.etName);
        etMessage = findViewById(R.id.etMessage);
        tvResult  = findViewById(R.id.tvResult);

        // Explicit Intent
        findViewById(R.id.btnExplicit).setOnClickListener(v -> {
            Intent i = new Intent(this, SecondActivity.class);
            i.putExtra("name",    etName.getText().toString());
            i.putExtra("message", etMessage.getText().toString());
            startActivity(i);
        });

        // Start Activity For Result
        findViewById(R.id.btnForResult).setOnClickListener(v -> {
            Intent i = new Intent(this, ResultActivity.class);
            startActivityForResult(i, REQUEST_CODE);
        });

        // Implicit Intent
        findViewById(R.id.btnImplicit).setOnClickListener(v -> {
            Intent i = new Intent(Intent.ACTION_VIEW);
            i.setData(Uri.parse("https://www.android.com"));
            startActivity(i);
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_CODE && resultCode == RESULT_OK && data != null) {
            String returned = data.getStringExtra("result");
            tvResult.setText("Returned: " + returned);
        }
    }
}
