package com.madlab.e03_intent;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import androidx.appcompat.app.AppCompatActivity;

public class ResultActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);
        if (getSupportActionBar() != null) getSupportActionBar().setTitle("Result Activity");

        EditText etReturn = findViewById(R.id.etReturnData);
        ((Button) findViewById(R.id.btnSendResult)).setOnClickListener(v -> {
            Intent result = new Intent();
            result.putExtra("result", etReturn.getText().toString());
            setResult(RESULT_OK, result);
            finish();
        });
    }
}
