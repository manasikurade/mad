package com.madlab.e03_intent;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        if (getSupportActionBar() != null) getSupportActionBar().setTitle("Second Activity");

        String name    = getIntent().getStringExtra("name");
        String message = getIntent().getStringExtra("message");

        ((TextView) findViewById(R.id.tvName)).setText("Name: " + (name != null ? name : "N/A"));
        ((TextView) findViewById(R.id.tvMessage)).setText("Message: " + (message != null ? message : "N/A"));

        ((Button) findViewById(R.id.btnBack)).setOnClickListener(v -> finish());
    }
}
