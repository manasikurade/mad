package com.madlab.e08_notifications;

import android.os.Bundle;
import android.widget.Button;
import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        if (getSupportActionBar() != null) getSupportActionBar().setTitle("Opened from Notification");
        ((Button) findViewById(R.id.btnBack)).setOnClickListener(v -> finish());
    }
}
