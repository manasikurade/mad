package com.madlab.e08_notifications;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private static final String CHANNEL_ID = "mad_lab_channel";
    private static final int NOTIF_SIMPLE   = 101;
    private static final int NOTIF_ACTION   = 102;
    private static final int NOTIF_BIG      = 103;
    private static final int NOTIF_PROGRESS = 104;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        createNotificationChannel();
        requestNotificationPermission();

        ((Button) findViewById(R.id.btnSimpleNotify)).setOnClickListener(v -> showSimpleNotification());
        ((Button) findViewById(R.id.btnActionNotify)).setOnClickListener(v -> showActionNotification());
        ((Button) findViewById(R.id.btnBigNotify)).setOnClickListener(v -> showBigTextNotification());
        ((Button) findViewById(R.id.btnProgressNotify)).setOnClickListener(v -> showProgressNotification());
        ((Button) findViewById(R.id.btnCancel)).setOnClickListener(v -> {
            NotificationManagerCompat.from(this).cancelAll();
            Toast.makeText(this, "All notifications cancelled", Toast.LENGTH_SHORT).show();
        });
    }

    private void showSimpleNotification() {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("Simple Notification")
            .setContentText("This is a basic notification from E08!")
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true);
        NotificationManagerCompat.from(this).notify(NOTIF_SIMPLE, builder.build());
    }

    private void showActionNotification() {
        Intent intent = new Intent(this, SecondActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        PendingIntent pendingIntent = PendingIntent.getActivity(this, 0, intent,
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.M ? PendingIntent.FLAG_IMMUTABLE : 0);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_send)
            .setContentTitle("Tap to Open Activity")
            .setContentText("Click this notification to open SecondActivity")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(pendingIntent)
            .addAction(android.R.drawable.ic_menu_view, "Open", pendingIntent)
            .setAutoCancel(true);
        NotificationManagerCompat.from(this).notify(NOTIF_ACTION, builder.build());
    }

    private void showBigTextNotification() {
        String bigText = "This is a Big Text notification! It can display a long message that " +
            "expands when the user swipes down on it. This is useful for emails, messages, " +
            "or any content that needs more space. Android Experiment 8 - Notifications.";

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_info_details)
            .setContentTitle("Big Text Notification")
            .setContentText("Expand to read full message...")
            .setStyle(new NotificationCompat.BigTextStyle().bigText(bigText))
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .setAutoCancel(true);
        NotificationManagerCompat.from(this).notify(NOTIF_BIG, builder.build());
    }

    private void showProgressNotification() {
        final NotificationManagerCompat notifManager = NotificationManagerCompat.from(this);
        final NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_upload)
            .setContentTitle("Downloading File...")
            .setContentText("Progress: 0%")
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOngoing(true);
        notifManager.notify(NOTIF_PROGRESS, builder.build());

        new Thread(() -> {
            for (int progress = 0; progress <= 100; progress += 10) {
                final int p = progress;
                try { Thread.sleep(400); } catch (InterruptedException ignored) {}
                new Handler(getMainLooper()).post(() -> {
                    builder.setProgress(100, p, false).setContentText("Progress: " + p + "%");
                    if (p >= 100) {
                        builder.setContentTitle("Download Complete ✓")
                               .setContentText("File downloaded successfully!")
                               .setProgress(0, 0, false).setOngoing(false);
                    }
                    notifManager.notify(NOTIF_PROGRESS, builder.build());
                });
            }
        }).start();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID, "MAD Lab Channel", NotificationManager.IMPORTANCE_DEFAULT);
            channel.setDescription("Channel for Mobile Application Development Lab");
            ((NotificationManager) getSystemService(NotificationManager.class))
                .createNotificationChannel(channel);
        }
    }

    private void requestNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.POST_NOTIFICATIONS)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 200);
            }
        }
    }
}
