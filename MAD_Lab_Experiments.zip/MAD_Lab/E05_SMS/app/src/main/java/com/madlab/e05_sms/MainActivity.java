package com.madlab.e05_sms;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class MainActivity extends AppCompatActivity {
    private static final int CALL_PERMISSION_CODE = 1;
    EditText etPhone, etMessage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etPhone   = findViewById(R.id.etPhone);
        etMessage = findViewById(R.id.etMessage);

        // Open dialer (no permission needed)
        ((Button) findViewById(R.id.btnDial)).setOnClickListener(v -> {
            String number = etPhone.getText().toString().trim();
            if (number.isEmpty()) { Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show(); return; }
            Intent intent = new Intent(Intent.ACTION_DIAL);
            intent.setData(Uri.parse("tel:" + number));
            startActivity(intent);
        });

        // Direct call (needs permission)
        ((Button) findViewById(R.id.btnCall)).setOnClickListener(v -> {
            String number = etPhone.getText().toString().trim();
            if (number.isEmpty()) { Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show(); return; }
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CALL_PHONE}, CALL_PERMISSION_CODE);
            } else {
                Intent intent = new Intent(Intent.ACTION_CALL);
                intent.setData(Uri.parse("tel:" + number));
                startActivity(intent);
            }
        });

        // Send SMS via messaging app
        ((Button) findViewById(R.id.btnSms)).setOnClickListener(v -> {
            String number  = etPhone.getText().toString().trim();
            String message = etMessage.getText().toString().trim();
            if (number.isEmpty()) { Toast.makeText(this, "Enter a phone number", Toast.LENGTH_SHORT).show(); return; }
            Intent intent = new Intent(Intent.ACTION_SENDTO);
            intent.setData(Uri.parse("smsto:" + number));
            intent.putExtra("sms_body", message);
            startActivity(intent);
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == CALL_PERMISSION_CODE && grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Permission granted. Press 'Direct Call' again.", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Permission denied. Use 'Open Dialer' instead.", Toast.LENGTH_SHORT).show();
        }
    }
}
