package com.madlab.e06_spinners;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Spinner - Planets
        Spinner spinnerPlanets = findViewById(R.id.spinnerPlanets);
        TextView tvSpinnerResult = findViewById(R.id.tvSpinnerResult);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
            this, R.array.planets_array, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerPlanets.setAdapter(adapter);
        spinnerPlanets.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> parent, android.view.View view, int pos, long id) {
                tvSpinnerResult.setText("Selected Planet: " + parent.getItemAtPosition(pos));
            }
            @Override public void onNothingSelected(AdapterView<?> parent) {}
        });

        // Alert Dialog
        findViewById(R.id.btnAlert).setOnClickListener(v -> {
            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle("Delete File?")
                   .setMessage("Are you sure you want to delete this file? This action cannot be undone.")
                   .setIcon(android.R.drawable.ic_dialog_alert)
                   .setPositiveButton("Yes, Delete", (dialog, id) ->
                       Toast.makeText(this, "File Deleted!", Toast.LENGTH_SHORT).show())
                   .setNegativeButton("Cancel", (dialog, id) ->
                       Toast.makeText(this, "Cancelled", Toast.LENGTH_SHORT).show())
                   .setCancelable(false)
                   .show();
        });

        // Popup
        findViewById(R.id.btnPopup).setOnClickListener(v -> {
            AlertDialog.Builder helpBuilder = new AlertDialog.Builder(this);
            helpBuilder.setTitle("📢 Pop Up Message");
            helpBuilder.setMessage("This is a simple popup dialog.\nYou can display any information here to the user.");
            helpBuilder.setPositiveButton("OK", (dialog, which) ->
                Toast.makeText(this, "OK Clicked!", Toast.LENGTH_SHORT).show());
            helpBuilder.setNeutralButton("Learn More", (dialog, which) ->
                Toast.makeText(this, "Learn More Clicked!", Toast.LENGTH_SHORT).show());
            helpBuilder.create().show();
        });

        // Toast - Short
        findViewById(R.id.btnToastShort).setOnClickListener(v ->
            Toast.makeText(this, "This is a Short Toast!", Toast.LENGTH_SHORT).show());

        // Toast - Long
        findViewById(R.id.btnToastLong).setOnClickListener(v -> {
            Toast toast = Toast.makeText(this, "This is a Long Toast message! It stays longer on screen.", Toast.LENGTH_LONG);
            toast.setGravity(Gravity.TOP | Gravity.CENTER_HORIZONTAL, 0, 100);
            toast.show();
        });

        // Input Dialog
        TextView tvDialogResult = findViewById(R.id.tvDialogResult);
        findViewById(R.id.btnInputDialog).setOnClickListener(v -> {
            AlertDialog.Builder inputBuilder = new AlertDialog.Builder(this);
            inputBuilder.setTitle("Enter Your Name");
            final EditText et = new EditText(this);
            et.setHint("Your name here");
            et.setPadding(48, 24, 48, 24);
            inputBuilder.setView(et);
            inputBuilder.setPositiveButton("Submit", (dialog, which) -> {
                String input = et.getText().toString();
                tvDialogResult.setText("Hello, " + (input.isEmpty() ? "Stranger" : input) + "! 👋");
            });
            inputBuilder.setNegativeButton("Cancel", null);
            inputBuilder.setCancelable(false);
            inputBuilder.show();
        });
    }
}
