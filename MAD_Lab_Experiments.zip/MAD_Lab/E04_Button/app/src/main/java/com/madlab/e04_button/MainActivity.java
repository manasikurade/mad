package com.madlab.e04_button;

import android.os.Bundle;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        EditText etInput       = findViewById(R.id.etInput);
        TextView tvOutput      = findViewById(R.id.tvOutput);
        Button btnShowText     = findViewById(R.id.btnShowText);
        Button btnNormal       = findViewById(R.id.btnNormal);
        Button btnIcon         = findViewById(R.id.btnIcon);
        CheckBox chkJava       = findViewById(R.id.chkJava);
        CheckBox chkPython     = findViewById(R.id.chkPython);
        CheckBox chkKotlin     = findViewById(R.id.chkKotlin);
        Button btnCheckResult  = findViewById(R.id.btnCheckResult);
        TextView tvCheckResult = findViewById(R.id.tvCheckResult);
        RadioGroup radioGroup  = findViewById(R.id.radioGroup);
        TextView tvRadioResult = findViewById(R.id.tvRadioResult);
        ToggleButton toggleBtn = findViewById(R.id.toggleBtn);
        TextView tvToggleStatus= findViewById(R.id.tvToggleStatus);

        // EditText button
        btnShowText.setOnClickListener(v ->
            tvOutput.setText("You typed: " + etInput.getText().toString()));

        // Normal button
        btnNormal.setOnClickListener(v ->
            Toast.makeText(this, "Normal Button Clicked!", Toast.LENGTH_SHORT).show());

        // Icon button
        btnIcon.setOnClickListener(v ->
            Toast.makeText(this, "Icon Button Clicked!", Toast.LENGTH_SHORT).show());

        // CheckBox result
        btnCheckResult.setOnClickListener(v -> {
            StringBuilder sb = new StringBuilder("Selected: ");
            if (chkJava.isChecked())   sb.append("Java ");
            if (chkPython.isChecked()) sb.append("Python ");
            if (chkKotlin.isChecked()) sb.append("Kotlin ");
            if (!chkJava.isChecked() && !chkPython.isChecked() && !chkKotlin.isChecked())
                sb.append("None");
            tvCheckResult.setText(sb.toString());
        });

        // Radio button listener
        radioGroup.setOnCheckedChangeListener((group, checkedId) -> {
            if (checkedId == R.id.rbMale)   tvRadioResult.setText("Selected: Male");
            else if (checkedId == R.id.rbFemale) tvRadioResult.setText("Selected: Female");
            else if (checkedId == R.id.rbOther)  tvRadioResult.setText("Selected: Other");
        });

        // Toggle button
        toggleBtn.setOnCheckedChangeListener((buttonView, isChecked) -> {
            tvToggleStatus.setText("Toggle is " + (isChecked ? "ON ✓" : "OFF ✗"));
            tvToggleStatus.setTextColor(isChecked ? 0xFF2E7D32 : 0xFFE53935);
        });
    }
}
